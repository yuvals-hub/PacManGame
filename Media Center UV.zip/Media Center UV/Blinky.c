/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher
 * Note(s): __USE_LCD   - enable Output on LCD, uncomment #define in code to use
 *  				for demo (NOT for analysis purposes)
 *----------------------------------------------------------------------------
 * Copyright (c) 2008-2011 Keil - An ARM Company.
 * Name: Anita Tino
 *----------------------------------------------------------------------------*/

#include <stdio.h>
#include "Blinky.h"
#include "LPC17xx.h"                       
#include "GLCD.h"
#include "LED.h"
//#include "Board_ADC.h" 
#include "KBD.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "type.h"
#include "usbdmain.h"

#define __FI        1                      /* Font index 16x24               */
#define __USE_LCD   0										/* Uncomment to use the LCD */
#define DELAY_2N		20

//------- ITM Stimulus Port definitions for printf ------------------- //
#define ITM_Port8(n)    (*((volatile unsigned char *)(0xE0000000+4*n)))
#define ITM_Port16(n)   (*((volatile unsigned short*)(0xE0000000+4*n)))
#define ITM_Port32(n)   (*((volatile unsigned long *)(0xE0000000+4*n)))

#define DEMCR           (*((volatile unsigned long *)(0xE000EDFC)))
#define TRCENA          0x01000000

struct __FILE { int handle;  };
FILE __stdout;
FILE __stdin;

int fputc(int ch, FILE *f) {
  if (DEMCR & TRCENA) {
    while (ITM_Port32(0) == 0);
    ITM_Port8(0) = ch;
  }
  return(ch);
}

// Declaring the game variables

extern unsigned char pacman[];
extern unsigned char BabyBlueGhost[];
extern unsigned char PinkGhost[];
extern unsigned char OrangeGhost[];
extern unsigned char EatGhost[];
extern unsigned char Donut[];
extern unsigned char Lebron[];
extern unsigned char BlackCircle[];
extern unsigned char pacChar[];
extern unsigned char blueG[];
extern unsigned char mario[];
extern unsigned char lebronSel[];
extern unsigned char marioSel[];

int character = 0;
int pg = 0;
int bg = 0;
int bbg = 0;
int og = 0;
int d = 0;
int highscore;
char high[10];
int PacMan_x;
int PacMan_y;
int BlueGhost_x;
int BlueGhost_y;
int PinkGhost_x;
int PinkGhost_y;
int BabyBlueGhost_x;
int BabyBlueGhost_y;
int OrangeGhost_x;
int OrangeGhost_y;
int Donut_x;
int Donut_y;
int lives;
int delay = 0;
int scoreNum;
char score[10];
int key = 0;
int pinkX = 0;
int pinkY = 0;
int blueX = 0;
int blueY = 0;
int bblueX = 0;
int bblueY = 0;
int orangeX = 0;
int orangeY = 0;
int mp3 = 0;
int flag;
int y;
int option = 0;

void Pacman();
void MainMenu();
int gameover();
void pacSelect();
void lebronSelect();
void marioSelect();
void PacmanMenu();
	

// Assigning default board X and Y coordinates to the figures

// Declaring & Defining variables 

static volatile uint16_t AD_dbg;

uint16_t ADC_last;                      // Last converted value
/* Import external variables from IRQ.c file                                  */
extern uint8_t  clock_ms;

// Bit Band Macros used to calculate the alias address at run time
#define ADDRESS(x)    (*((volatile unsigned long *)(x)))
#define BitBand(x, y) 	ADDRESS(((unsigned long)(x) & 0xF0000000) | 0x02000000 |(((unsigned long)(x) & 0x000FFFFF) << 5) | ((y) << 2))
#define PIN1_28 (*((volatile unsigned long *)(0x233806F0)))
#define PIN1_29 (*((volatile unsigned long *)(0x233806F4)))	
#define PIN2_2  (*((volatile unsigned long *)(0x23380A88)))


volatile unsigned long * bit;
#define ADCR_Bit24   (*((volatile unsigned long *)0x42680060
	
extern int audio_main(void);
extern int audioResume(void);

void LCDreset(){
			LED_Off(2);
			LED_Off(1);
			LED_Off(0);
}
	
// Board pixel boundaries: X Max = 290, Y Max = 210 

// Functions to randomly generate X and Y coordinates on the board 

void delayT(int count){
	count <<= DELAY_2N;
	while(count--);
}

int xRanGen(){
	int lower = 0, upper = 290;
	int num = (rand() % (upper - lower + 1)) + lower;
	return num;
}

int yRanGen(){
	int lower = 0, upper = 210;
	int num = (rand() % (upper - lower + 1)) + lower;
	return num;
}

int xRanMove(){
	int x = rand();
	if(x % 2 == 0)
		return 1;
	else
		return -1;
}

int yRanMove(){
	int y = rand();
	if(y % 2 == 0)
		return 1;
	else
		return -1;
}
	
// Function called to reset the characters to random locations on the LCD
void reset(){

// Key game attribute reset
key = 0;
pg = 0;
bg = 0;
bbg = 0;
og = 0;
d = 0;
	
// Position intializations for each character
PacMan_x = 145;
PacMan_y = 85;
BlueGhost_x = 289;
BlueGhost_y = 1;
PinkGhost_x = 289;
PinkGhost_y = 209;	
BabyBlueGhost_x = 1;
BabyBlueGhost_y = 209;
OrangeGhost_x = 1;
OrangeGhost_y = 1;
Donut_x = xRanGen();
Donut_y = yRanGen();
	
// Random movement functions that set the x/y direction of each ghost 	
pinkX = xRanMove();
pinkY = yRanMove();		
blueX = xRanMove();
blueY = yRanMove();
bblueX = xRanMove();
bblueY = yRanMove();
orangeX = xRanMove();
orangeY = yRanMove();	
}
	
// Function to move Pacman depending on the 'move' input which refers to the Joystick 

void ledLifes(int l){
	
	int led = l;
	
	if(led == 3){
			LED_On(2);
			LED_On(1);
			LED_On(0);
	} else if(led ==2){
			LED_Off(2);
			LED_On(1);
			LED_On(0);
	} else if(led == 1){
			LED_Off(2);
			LED_Off(1);
			LED_On(0);
	} else{
		  LED_Off(2);
			LED_Off(1);
			LED_Off(0);
	}
}

int collision(int x1, int y1, int x2, int y2){
	
	int x1L = x1 - 15;
	int x2L = x2 - 15;
	int x1R = x1 + 15;
	int x2R = x2 + 15;
	int y1U = y1 - 15;
	int y2U = y2 - 15;
	int y1D = y1 + 15;
	int y2D = y2 + 15;
	
	if((y1D <= y2U) || (y1U >= y2D) || (x1R <= x2L) || (x1L >= x2R)){
		return(0);
	}
	else{
		return(1);
	}
}

int DonutColl(int x1, int y1, int x2, int y2){
	
	int x1L = x1 - 15;
	int x2L = x2 - 15;
	int x1R = x1 + 15;
	int x2R = x2 + 15;
	int y1U = y1 - 15;
	int y2U = y2 - 15;
	int y1D = y1 + 15;
	int y2D = y2 + 15;
	
	if((y1D <= y2U) || (y1U >= y2D) || (x1R <= x2L) || (x1L >= x2R)){
		return(0);
	}
	else{
		key = 1;
		return(1);
	}
}


void PacMove(int move){
	
	int gamebutton = move;
	
	//Collision detection when Ghosts are not edible
	
	if(key == 0){
		if(collision(PacMan_x, PacMan_y, PinkGhost_x, PinkGhost_y) == 1){
			lives --;
			GLCD_Clear(Black);
			reset();
		}
		
		else if(collision(PacMan_x, PacMan_y, BlueGhost_x, BlueGhost_y) == 1){
			lives --;
			GLCD_Clear(Black);
			reset();
		}
		
		else if(collision(PacMan_x, PacMan_y, BabyBlueGhost_x, BabyBlueGhost_y) == 1){
			lives --;
			GLCD_Clear(Black);
			reset();
		}
				
		else if(collision(PacMan_x, PacMan_y, OrangeGhost_x, OrangeGhost_y) == 1){
			lives --;
			GLCD_Clear(Black);
			reset();
		}
		
		if(DonutColl(PacMan_x, PacMan_y, Donut_x, Donut_y) == 1){			
			key = 1;
			d = 1;
			GLCD_Clear(Black);
		}
	}
	
 //Collision detection when Ghosts are not edible
	
	if(key == 1){
		
		if((collision(PacMan_x, PacMan_y, PinkGhost_x, PinkGhost_y) == 1) && pg == 0){
			scoreNum = scoreNum + 200;
			pg = 1;
			GLCD_Clear(Black);
		}
		
		if((collision(PacMan_x, PacMan_y, BlueGhost_x, BlueGhost_y) == 1) && bg == 0){
			scoreNum = scoreNum + 200;
			bg = 1;
			GLCD_Clear(Black);
		}
		
		if((collision(PacMan_x, PacMan_y, BabyBlueGhost_x, BabyBlueGhost_y) == 1) && bbg == 0){
			scoreNum = scoreNum + 200;
			bbg = 1;
			GLCD_Clear(Black);
		}
		
		if((collision(PacMan_x, PacMan_y, OrangeGhost_x, OrangeGhost_y) == 1) && og == 0){
			scoreNum = scoreNum + 200;
			og = 1;
			GLCD_Clear(Black);
		}	
	}

		if(gamebutton == JOYSTICK_RIGHT && PacMan_x < 289){
				PacMan_x = PacMan_x + 2;
		}
		else if(gamebutton == JOYSTICK_LEFT && PacMan_x > 1){
				PacMan_x = PacMan_x - 2;
		}
		else if(gamebutton == JOYSTICK_UP && PacMan_y > 1){
				PacMan_y = PacMan_y - 2;
		}
		else if(gamebutton == JOYSTICK_DOWN && PacMan_y < 209){
				PacMan_y = PacMan_y + 2;
		}
	}

// Function that randomly moves the ghosts

void PinkMove(){
	
	PinkGhost_x = PinkGhost_x + pinkX;
	PinkGhost_y = PinkGhost_y + pinkY;
	
	if(PinkGhost_x > 290 || PinkGhost_x < 0){
		pinkX = pinkX * -1;
	}
	else if(PinkGhost_y > 210 || PinkGhost_y < 0){
			pinkY = pinkY * -1;
	}
}

void BabyBlueMove(){
	
	BabyBlueGhost_x = BabyBlueGhost_x + bblueX;
	BabyBlueGhost_y = BabyBlueGhost_y + bblueY;
	
	if(BabyBlueGhost_x > 290 || BabyBlueGhost_x < 0){
		bblueX = bblueX * -1;
	}
	else if(BabyBlueGhost_y > 210 || BabyBlueGhost_y < 0){
			bblueY = bblueY * -1;
	}
}

void OrangeMove(){
	
	OrangeGhost_x = OrangeGhost_x + orangeX;
	OrangeGhost_y = OrangeGhost_y + orangeY;
	
	if(OrangeGhost_x > 290 || OrangeGhost_x < 0){
		orangeX = orangeX * -1;
	}
	else if(OrangeGhost_y > 210 || OrangeGhost_y < 0){
			orangeY = orangeY * -1;
	}
}

void BlueMove(){
	
	BlueGhost_x = BlueGhost_x + blueX;
	BlueGhost_y = BlueGhost_y + blueY;
	
	if(BlueGhost_x > 290 || BlueGhost_x < 1){
		blueX = blueX * -1;
	}
	else if(BlueGhost_y > 210 || BlueGhost_y < 1){
			blueY = blueY * -1;
	}
}

int gameover(){
	
	int stick;
		
	int selection = 1; 
	
	sprintf(score, "%d", scoreNum);
	
		while(1){
			
		stick = Joystick_GetState();
		
	  if(stick == JOYSTICK_DOWN){
				if(selection == 2){
					selection = 0;
				}
				else {
					selection++;
				}
			}
			else if(stick == JOYSTICK_UP){
				if(selection == 1){
					selection = 2;
				}
				else{
					selection--;
				}
			}
			
		if(selection == 1){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 2, __FI, "    GAME OVER   ");
					GLCD_DisplayString(2, 0, __FI, "    Score:   ");
			    GLCD_DisplayString(2, 12, __FI, (unsigned char *)score);
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(4, 2, __FI, "    NEW GAME ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU     ");
					#endif
			if(stick == JOYSTICK_CENTER){
					GLCD_Clear(Black); 
					flag = 1;
					option = 1;
					y = 1;
					return 1;
			}
		}
		
		else if(selection == 2){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 2, __FI, "    GAME OVER   ");
					GLCD_DisplayString(2, 0, __FI, "    Score:   ");
			    GLCD_DisplayString(2, 12, __FI, (unsigned char *)score);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(4, 2, __FI, "    NEW GAME ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU     ");
					#endif
				if(stick == JOYSTICK_CENTER){
					GLCD_Clear(Black); 
					flag = 1;
					y = 1;
					option = 2;
					return 2;
			}
		}
	}
		
	switch(option){
		case 1: 
			Pacman();
		case 2:
			MainMenu();
	}
}

int pauseMenu(){
	
	int stick;
	
	int selection = 1; 
	
		while(1){
			
		stick = Joystick_GetState();
		
	  if(stick == JOYSTICK_DOWN){
				if(selection == 3){
					selection = 0;
				}
				else {
					selection++;
				}
			}
			else if(stick == JOYSTICK_UP){
				if(selection == 1){
					selection = 3;
				}
				else{
					selection--;
				}
			}
			
		if(selection == 1){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 1, __FI, "    GAME PAUSED   ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(2, 3, __FI, "    RESUME   ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(4, 3, __FI, "    RESTART ");
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU     ");
					#endif
			if(stick == JOYSTICK_CENTER){
					GLCD_Clear(Black);
					option = 0;
					return 0;
					break;
			}
		}
		
		else if(selection == 2){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 1, __FI, "    GAME PAUSED   ");
					GLCD_SetTextColor(Red);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 3, __FI, "    RESUME    ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(4, 3, __FI, "    RESTART ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU     ");
					#endif
		
				if(stick == JOYSTICK_CENTER){
					flag = 1;
					option = 1;
					y = 1;
					return 1;
			}
		}
		
		else if(selection == 3){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 1, __FI, "    GAME PAUSED   ");
					GLCD_SetTextColor(Red);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 3, __FI, "    RESUME    ");
					GLCD_DisplayString(4, 3, __FI, "    RESTART ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU     ");
					#endif
			if(stick == JOYSTICK_CENTER){
				flag = 1;
				option = 2;	
				y = 1;
				return 2;
			}
		}
	}
}

// Pacman game method
	
void Pacman(){
	
	int gamebutton;
	
	int i = 0;
	
	int stick;
	int selection = 1;
	int y = 0;
	
	lives = 3;
	reset();
	flag = 0;
	scoreNum = 0;
	
	sprintf(high, "%d", highscore);
		
	GLCD_Clear(Black);
	
	// Cool starting menu
	
	
	/*
	for (i = 0; i < 100; i++){			
			GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, PinkGhost);
		  GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, blueG);	
			GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, BabyBlueGhost);	
		  GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, OrangeGhost);
			GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, PacRight);
			GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, PacLeft);
			GLCD_Bitmap(xRanGen(), yRanGen(), 30, 30, PacUp);
	}
	*/
	
	
					#ifdef __USE_LCD
					GLCD_Clear(Black);
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 0, __FI, "    FIND THE DONUT   ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(2, 0, __FI, "    EAT THE GHOSTS   ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(4,0, __FI," High Score:");
					GLCD_DisplayString(4, 14, __FI,    (unsigned char *)high	 );
					GLCD_DisplayString(6, 0, __FI, "  ");
					#endif
	
	// waits for the Joystick center to start the game 
	
	while(y == 0){
		
		gamebutton = Joystick_GetState();
		if(gamebutton == JOYSTICK_CENTER){
			for(delay = 0; delay < 1; delay++){
				GLCD_Clear(Black);
		}
		
		gamebutton = Joystick_GetState();
		
		// While loop to run game until the Joystick center is pressed or player loses 
		
	while(flag == 0){
		
		if(gamebutton == JOYSTICK_CENTER){
				GLCD_Clear(Black);
				option = pauseMenu();
		}			
		
		sprintf(score, "%d", scoreNum);
		
		#ifdef __USE_LCD
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 9, __FI, (unsigned char *)score);
		#endif
		
		ledLifes(lives);
		
		if(lives <= 0){
			if(highscore < scoreNum){
				highscore = scoreNum;
			}
			GLCD_Clear(Black);
			option = gameover();
			//break;
		}
		
		// Game when ghosts are not edible

		game:
		
		if(key == 0){
			
				//Pacman Mapping
				switch(character){
					case 0:
							GLCD_Bitmap(PacMan_x, PacMan_y, 30, 30, pacman);
							break;
					case 1:
							GLCD_Bitmap(PacMan_x, PacMan_y, 30, 30, Lebron);
							break;
					case 2:
							GLCD_Bitmap(PacMan_x, PacMan_y, 30, 30, mario);
							break;
				}
		
				// Ghost LCD Mapping 
				
				GLCD_Bitmap(PinkGhost_x,PinkGhost_y , 30, 30, PinkGhost);			
				GLCD_Bitmap(BabyBlueGhost_x, BabyBlueGhost_y, 30, 30, BabyBlueGhost);			
				GLCD_Bitmap(OrangeGhost_x, OrangeGhost_y, 30, 30, OrangeGhost);
				GLCD_Bitmap(BlueGhost_x, BlueGhost_y, 30, 30, blueG);
							
				GLCD_Bitmap(Donut_x,Donut_y, 30, 30, Donut);
				
				gamebutton = Joystick_GetState();
				
				PinkMove();
				BlueMove();
				BabyBlueMove();
				OrangeMove();
					
				PacMove(gamebutton);

		}
		
		else if(key == 1){		
			
			if(pg == 1 && bg == 1 && bbg == 1 && og == 1){
						GLCD_Clear(Black);
						reset();
						goto game;
			}
			
				switch(character){
					case 0:
							GLCD_Bitmap(PacMan_x, PacMan_y, 30, 30, pacman);
							break;
					case 1:
							GLCD_Bitmap(PacMan_x, PacMan_y, 30, 30, Lebron);
							break;
					case 2:
							GLCD_Bitmap(PacMan_x, PacMan_y, 30, 30, mario);
							break;
				}
				
				// Ghost LCD Mapping 
			
				if(pg == 0)		
						GLCD_Bitmap(PinkGhost_x,PinkGhost_y , 30, 30, EatGhost);

				if(bg == 0)
						GLCD_Bitmap(BlueGhost_x, BlueGhost_y, 30, 30, EatGhost);					
			
				if(bbg == 0)
						GLCD_Bitmap(BabyBlueGhost_x, BabyBlueGhost_y, 30, 30, EatGhost);		
						
				if(og == 0)
						GLCD_Bitmap(OrangeGhost_x, OrangeGhost_y, 30, 30, EatGhost);	
					
				gamebutton = Joystick_GetState();

				PinkMove();
				BlueMove();
				BabyBlueMove();
				OrangeMove();						
					
				PacMove(gamebutton);
				}
		}
				switch(option){
				case 1:
					flag = 1;
					y = 1;
					GLCD_Clear(Black);
					Pacman();
					break;
				case 2:
					flag = 1;
					y = 1;
					GLCD_Clear(Black);
					MainMenu();
					break;
				}						
			}
		}		
	}

void pacmanControls(){
	
	int gamestick;
	
	while(1){
		
		gamestick = Joystick_GetState();
		
					#ifdef __USE_LCD
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 0, __FI, "    GAME CONTROLS   ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 0, 1, "USE JOYSTICK TO MOVE");
					GLCD_DisplayString(4, 3, 1, "FIND THE DONUT");
					GLCD_DisplayString(6, 3, 1, "EAT THE GHOSTS ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(8, 1, 1, "JOYSTICK TO RETURN");
					#endif
				
				if(gamestick == JOYSTICK_CENTER){
					GLCD_Clear(Black); 
					PacmanMenu();
					break;
		}
	}
}

// Pacman Menu method
	
void PacmanMenu(){
	
	int stick;
	
	int selection = 1; 
	
		while(1){
			
		stick = Joystick_GetState();
		
	  if(stick == JOYSTICK_DOWN){
				if(selection == 3){
					selection = 0;
				}
				else {
					selection++;
				}
			}
			else if(stick == JOYSTICK_UP){
				if(selection == 1){
					selection = 3;
				}
				else{
					selection--;
				}
			}
			
		if(selection == 1){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    PACMAN   ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(2, 1, __FI, "    START GAME   ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(4, 2, __FI, "    CONTROLS ");
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU    ");
					#endif
			if(stick == JOYSTICK_CENTER){
					GLCD_Clear(Black);
					Pacman();
					break;
			}
		}
		
		else if(selection == 2){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    PACMAN   ");
					GLCD_SetTextColor(Red);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 1, __FI, "    START GAME    ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(4, 2, __FI, "    CONTROLS ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU    ");
					#endif
			
			if(stick == JOYSTICK_CENTER){
					GLCD_Clear(Black); 
					pacmanControls();
					break;
			}
	}
		
		else if(selection == 3){
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    PACMAN   ");
					GLCD_SetTextColor(Red);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 1, __FI, "    START GAME    ");
					GLCD_DisplayString(4, 2, __FI, "    CONTROLS ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(6, 2, __FI, "    MAIN MENU    ");
					#endif
			if(stick == JOYSTICK_CENTER){
				GLCD_Clear(Black); 
				MainMenu();
				break;
			}
		}
	}
}

void pacSelect(){
	
		int x;
	
		#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    PACMAN   ");
		#endif
	
		GLCD_Bitmap(140, 85, 45, 45, pacChar);
		
		while(1){
			
		x = Joystick_GetState();
	
		if(x == JOYSTICK_CENTER){
						character = 0;
						GLCD_Clear(Black);
						MainMenu();
						break;
		} else if(x == JOYSTICK_RIGHT){
			GLCD_Clear(Black);
			lebronSelect();
			break;
		} else if(x == JOYSTICK_LEFT){
			GLCD_Clear(Black);
			marioSelect();
			break;	
		}
		
	}
		
	
}

void lebronSelect(){
	
		int x;
	
		#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    LEBRON   ");
		#endif
	
		GLCD_Bitmap(140, 85, 55, 55, lebronSel);
		
		while(1){
			
		x = Joystick_GetState();
	
		if(x == JOYSTICK_CENTER){
						character = 1;
						GLCD_Clear(Black);
						MainMenu();
						break;
		} else if(x == JOYSTICK_RIGHT){
			GLCD_Clear(Black);
			marioSelect();
			break;
		} else if(x == JOYSTICK_LEFT){
			GLCD_Clear(Black);
			pacSelect();
			break;	
		}
	}
}

void marioSelect(){
	
		int x;
	
		#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    MARIO   ");
		#endif
	
		GLCD_Bitmap(140, 85, 41, 55, marioSel);
		
		while(1){
			
		x = Joystick_GetState();
	
		if(x == JOYSTICK_CENTER){
						character = 2;
						GLCD_Clear(Black);
						MainMenu();
						break;
		} else if(x == JOYSTICK_RIGHT){
			GLCD_Clear(Black);
			pacSelect();
			break;
		} else if(x == JOYSTICK_LEFT){
			GLCD_Clear(Black);
			lebronSelect();
			break;	
		}
	}
}


// Main Menu Method
	
	void MainMenu(){
		
		int x;
		int select = 1;

		LCDreset();
		
		while(1){
			
			x = Joystick_GetState();
			
			if(x == JOYSTICK_DOWN){
				if(select == 3){
					select = 0;
				}
				else {
					select++;
				}
			}
			else if(x == JOYSTICK_UP){
				if(select == 1){
					select = 3;
				}
				else{
					select--;
				}
			}
			
			if(select == 1){

					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    UV-BOY   ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(2, 3, __FI, "    PACMAN   ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(4, 0, __FI, "    CHOOSE PLAYER ");
					GLCD_DisplayString(6, 1, __FI, "    MP3 PLAYER     ");
					#endif			
				if(x == JOYSTICK_CENTER){
					GLCD_Clear(Black); 
					PacmanMenu();
					break;
			}
		}
			
			else if(select == 2){
			
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    UV-BOY   ");
					GLCD_SetTextColor(Red);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 3, __FI, "    PACMAN    ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(4, 0, __FI, "    CHOOSE PLAYER ");
					GLCD_SetTextColor(White);
					GLCD_DisplayString(6, 1, __FI, "    MP3 PLAYER     ");
					#endif
				
				if(x == JOYSTICK_CENTER){
					GLCD_Clear(Black); 
					pacSelect();
					break;
			}
		}
			
			else if(select == 3){
				
					#ifdef __USE_LCD                        
					GLCD_SetBackColor(Black);
					GLCD_SetTextColor(Yellow);
					GLCD_DisplayString(0, 3, __FI, "    UV-BOY   ");
					GLCD_SetTextColor(Red);
					GLCD_SetTextColor(White);
					GLCD_DisplayString(2, 3, __FI, "    PACMAN    ");
					GLCD_DisplayString(4, 0, __FI, "    CHOOSE PLAYER ");
					GLCD_SetTextColor(Red);
					GLCD_DisplayString(6, 1, __FI, "    MP3 PLAYER     ");
					#endif
				
				if(x == JOYSTICK_CENTER){
					//flag = 1;
					GLCD_Clear(Black);
					if(mp3 == 0){
					mp3++;
					audio_main();
					}
					else{
						audioResume();
						break;
				}	
			}
		}
	}
}
	
	
/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/

	
	int main (void) {
	
  //SystemCoreClockUpdate();
  //SysTick_Config(SystemCoreClock/100);       /* Generate interrupt each 10 ms */
	
	LED_Init();                                /* LED Initialization            */
  //ADC_Initialize();                                /* ADC Initialization            */
  GLCD_Init();                               /* Initialize graphical LCD (if enabled */
	Joystick_Initialize();
		
	#ifdef __USE_LCD
		GLCD_Clear(Black);
	#endif
		
	MainMenu();
		
}


